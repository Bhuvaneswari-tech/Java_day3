package Relationship;

public class Person {
	protected String name;
	protected int age;
	
	public void displayInfo() {
		System.out.println("Name: "+name);
		System.out.println("Age: "+age);
	}
}
