package Oops;

public interface SchoolMember {
	void showRole();
	//interface consist of only abstract method
	//public abstract void showRole();
}
