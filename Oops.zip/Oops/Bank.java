package Oops;

public interface Bank {
	double getInterestRate();
	String getBankName();
}
