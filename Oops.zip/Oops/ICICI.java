package Oops;

public class ICICI implements Bank{

	@Override
	public double getInterestRate() {
		// TODO Auto-generated method stub
		return 7.0;
	}

	@Override
	public String getBankName() {
		// TODO Auto-generated method stub
		return "ICICI Bank";
	}

}
