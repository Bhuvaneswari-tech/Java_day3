package Oops;

public class SBI implements Bank{

	@Override
	public double getInterestRate() {
		// TODO Auto-generated method stub
		return 6.5;
	}

	@Override
	public String getBankName() {
		// TODO Auto-generated method stub
		return "State Bank of Inida";
	}
	
}
